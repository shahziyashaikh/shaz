        <footer>
            <div class="container">
                <span class="text-muted"> Janseva Bank Pvt. Ltd. </span>
            </div>
        </footer>
    </body>
</html>