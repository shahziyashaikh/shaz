<?php
    require('header.php');
?>

    <section class="modal-open flex-shrink-0" style="background: white; overflow:hidden">
        <div class="careers">
            <h2 class="mt-5 col-md-12"> Careers </h2>
            <div class="career-info">
                Current job openings: &nbsp 0 <br/>
                Please check later.
            </div>
        </div>
    </section>

<?php
    require('footer.php'); 
?>
